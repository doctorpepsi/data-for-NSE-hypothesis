% this progame is for the hypothesis test for NSE between two sample splitting schemes.
% the PDF of NSE in calibration and validation periods are dependent. and
% their joint PDF are determind by Copula function.
% this program is draft that should be optimized for improving the
% computing efficiency. if you have any questions, please contace me
% dediliu@whu.edu.cn


clear;
inputdata=xlsread('result_2schemes.xlsx');
NO_obs= round(inputdata(1,1));
NO_cal1=round(inputdata(1,2));
NO_cal2=round(inputdata(1,3));
NO_val1=round(inputdata(1,4));
NO_val2=round(inputdata(1,5));

Q_obs=inputdata(2:end,1);
Q_cal1=inputdata(2:NO_cal1+1,2);
Q_cal2=inputdata(2:NO_cal2+1,3);
Q_val1=inputdata(2:NO_val1+1,4);
Q_val2=inputdata(2:NO_val2+1,5);
Q_obsforcal1=inputdata(2:NO_cal1+1,1); %the observed data should match the calibration
Q_obsforval1=inputdata(NO_cal1+2:end,1);%the observed data should match the validation
Q_obsforcal2=inputdata(2:NO_cal2+1,1); %the observed data should match the calibration
Q_obsforval2=inputdata(NO_cal2+2:end,1);%the observed data should match the validation
Q_simu1=[Q_cal1;Q_val1];
Q_simu2=[Q_cal2;Q_val2];

% linear regression model between observation and simulation
scatter(Q_obs,Q_simu1,20,'k');
scatter(Q_obs,Q_simu2,20,'r');
%for calibration period
[A_cal1,B_cal1,C_cal1,DEL_cal1,NSE_E_cal1] = NSE_estimation(Q_obsforcal1,Q_cal1);
[A_val1,B_val1,C_val1,DEL_val1,NSE_E_val1] = NSE_estimation(Q_obsforval1,Q_val1);
[A_cal2,B_cal2,C_cal2,DEL_cal2,NSE_E_cal2] = NSE_estimation(Q_obsforcal2,Q_cal2);
[A_val2,B_val2,C_val2,DEL_val2,NSE_E_val2] = NSE_estimation(Q_obsforval2,Q_val2);

m_cal1=ones(1,NO_cal1);
delta_cal1=zeros(1,NO_cal1);
sigma_cal1=0;
const_cal1=1;
lambda_cal1=C_cal1*DEL_cal1;

m_cal2=ones(1,NO_cal2);
delta_cal2=zeros(1,NO_cal2);
sigma_cal2=0;
const_cal2=1;
lambda_cal2=C_cal2*DEL_cal2;
p_cal1=1-gx2cdf_davies(NSE_E_cal1,lambda_cal1',m_cal1,delta_cal1,sigma_cal1,const_cal1);
p_cal2=1-gx2cdf_davies(NSE_E_cal2,lambda_cal2',m_cal2,delta_cal2,sigma_cal2,const_cal2);

m_val1=ones(1,NO_val1);
delta_val1=zeros(1,NO_val1);
sigma_val1=0;
const_val1=1;
lambda_val1=C_val1*DEL_val1;

m_val2=ones(1,NO_val2);
delta_val2=zeros(1,NO_val2);
sigma_val2=0;
const_val2=1;
lambda_val2=C_val2*DEL_val2;
p_val1=1-gx2cdf_davies(NSE_E_val1,lambda_val1',m_val1,delta_val1,sigma_val1,const_val1);
p_val2=1-gx2cdf_davies(NSE_E_val2,lambda_val2',m_val2,delta_val2,sigma_val2,const_val2);

str_p_cal0=['NSE_E_cal1=' num2str(NSE_E_cal1)];
str_p_cal1=[str_p_cal0 ' and its probability is ' num2str(p_cal1*100) '%'];
disp(str_p_cal1);
str_p_cal00=['NSE_E_cal2=' num2str(NSE_E_cal2)];
str_p_cal2=[str_p_cal00 ' and its probability is ' num2str(p_cal2*100) '%'];
disp(str_p_cal2);
str_p_val0=['NSE_E_val1=' num2str(NSE_E_val1)];
str_p_val1=[str_p_val0 ' and its probability is ' num2str(p_val1*100) '%'];
disp(str_p_val1);
str_p_val00=['NSE_E_val2=' num2str(NSE_E_val2)];
str_p_val2=[str_p_val00 ' and its probability is ' num2str(p_val2*100) '%'];
disp(str_p_val2);

    
% for the differences in calibration periods
if (NSE_E_cal1>NSE_E_cal2) && (p_cal1>p_cal2)
    difference=1;
    disp('The performance of the first hydrologic model is better than the second one in calbration period!');
    cdf_difereca_ca=10;% represnet the (NSE_E_cal1>NSE_E_cal2) && (p_cal1>p_cal2)
else if  (NSE_E_cal1<NSE_E_cal2) && (p_cal1<p_cal2)
        difference=2;
        disp('The performance of the second hydrologic model is better than the first one in calbration period!');
        cdf_difereca_ca=5;% represnet the (NSE_E_cal1<NSE_E_cal2) && (p_cal1<p_cal2)
    else
      disp('Hypothesis tesing in calibration period should be done!');  
      diferecaj=NSE_E_cal1-NSE_E_cal2;
      KCC12=1;
     for i=1:2000
        diferevalue0(i)=-1+(i)/1000;
        temp_a0=diferevalue0(i);
        KK00=1;
        TT2=(-1:0.001:1);
        number_TT2=2000;
        jj2=0;
        YYY2=[];
        VVt2=[];
        UUt2=[];
        U2=[];
        V2=[];
        for j=1:number_TT2
            if (TT2(j)+temp_a0)<0.60 
                continue;
            end
            Ut2=gx2cdf_davies(TT2(j)+temp_a0,lambda_cal1',m_cal1,delta_cal1,sigma_cal1,const_cal1);
            if Ut2<0.00001
                continue;
            end
            Vt2=gx2cdf_davies(TT2(j),lambda_cal2',m_cal2,delta_cal2,sigma_cal2,const_cal2); 
            jj2=jj2+1;
            if Ut2>0.9999999
                Ut2=0.9999999;
            end
            if Vt2>0.9999999
                Vt2=0.9999999;
            end
                UUt2(jj2)=Ut2;
                VVt2(jj2)=Vt2;
                YYY2(jj2)=TT2(j);
            if (Ut2>0.0001) & (Vt2>0.0001)
                if (Ut2<1) & (Vt2<0.99999)  
                    U2(KK00)=Ut2; 
                    V2(KK00)=Vt2;         
                    KK00=KK00+1; 
                end
            end
        end  
            if KK00<2
                continue;
            else           
                WW2=[U2(:) V2(:)];        
                paramhat2=copulafit('Clayton',WW2);
                WWW2=[UUt2(:) VVt2(:)];
                pdf_z_y2=copulapdf('Clayton',WWW2,paramhat2);
                if size(YYY2)==1
                    continue
                else
                    pdf_diferevalue_cal(KCC12)=trapz(YYY2,pdf_z_y2); 
                end
                zzz_cal(KCC12)=temp_a0;          
                KCC12=KCC12+1;          
            end
    end

  [indexcal0,minv0]=min(abs(diferecaj-zzz_cal));
  [indexcal00,minv00]=min(abs(-diferecaj-zzz_cal));
 for i=2:( KCC12-1)
   cdf_diferevalue_cal(i)=trapz(zzz_cal(1:i), pdf_diferevalue_cal(1:i));
   if cdf_diferevalue_cal(i)>1
       cdf_diferevalue_cal(i)=1;
   end
 end
  cdf_difereca_ca=cdf_diferevalue_cal(minv0)-cdf_diferevalue_cal(minv00);  
  
  if diferecaj>0     
     if cdf_difereca_ca<0.95
        difference=0;   %there is no significant different between two models             
     else
        difference=1;   % NSE_E_cal1 >NSE_E_cal2
     end
  else if diferecaj==0
          difference=0;   %there is no significant difference between two models          
      else          
          if cdf_difereca_ca<0.95
            difference=0;   %there is no significant difference between NSE_E_cal1 and NSE_E_cal1 
          else
            difference=2;   % NSE_E_cal2 <NSE_E_cal2 
          end  
       end
  end
  if difference==0
     str_dif='There is no significant difference between two models in calbration period!';
  else if difference==1
        str_dif='The first model performances is significant better than the second one in calbration period!';
      else
        str_dif='The second model performances is significant better than the first one in calbration period!';
      end
  end
      str_QQ=['diferecaj=' num2str(diferecaj)];
      str_prob_QQ=['prob_diferecaj=' num2str(cdf_difereca_ca)];
      disp(str_QQ);
      disp(str_prob_QQ);
      disp(str_dif);    
    end
end
   save('prob_difereNSE_cal.mat','zzz_cal','pdf_diferevalue_cal','cdf_diferevalue_cal'); 
% for the differences in valibration periods
if (NSE_E_val1>NSE_E_val2) && (p_val1>p_val2)
    difference2=1;
    disp('The performance of the first hydrologic model is better than the second one in validation period!');
    cdf_difereca_ca=10;% represnet the (NSE_E_val1>NSE_E_val2) && (p_val1>p_val2)
else if  (NSE_E_val1<NSE_E_val2) && (p_val1<p_val2)
        difference2=2;
        disp('The performance of the second hydrologic model is better than the first one in validation period!');
        cdf_difereca_ca=5;% represnet the (NSE_E_cal1<NSE_E_cal2) && (p_cal1<p_cal2)
    else
      disp('Hypothesis tesing in validation period should be done!');  
      difereval=NSE_E_val1-NSE_E_val2;     
      KVV12=1;
      for i=1:2000
        diferevalue1(i)=-1+(i)/1000;
        temp_a1=diferevalue1(i);
        KK00=1;
        TT2=(-1:0.001:1);
        number_TT2=2000;
        jj2=0;
        YYY2=[];
        VVt2=[];
        UUt2=[];
        U2=[];
        V2=[];
        for j=1:number_TT2
            if (TT2(j)+temp_a1)<0.60 
                continue;
            end
            Ut2=gx2cdf_davies(TT2(j)+temp_a1,lambda_val1',m_val1,delta_val1,sigma_val1,const_val1);
            if Ut2<0.00001
                continue;
            end
            Vt2=gx2cdf_davies(TT2(j),lambda_val2',m_val2,delta_val2,sigma_val2,const_val2); 
            jj2=jj2+1;
            if Ut2>0.9999999
               Ut2=0.9999999;
            end
            if Vt2>0.9999999
                Vt2=0.9999999;
            end
            UUt2(jj2)=Ut2;
            VVt2(jj2)=Vt2;
            YYY2(jj2)=TT2(j);
            if (Ut2>0.0001) & (Vt2>0.0001)
                if (Ut2<1) & (Vt2<0.99999)  
                    U2(KK00)=Ut2; 
                    V2(KK00)=Vt2;     
                    KK00=KK00+1; 
                end
            end
        end  
      if KK00<2
         continue;
      else           
         WW2=[U2(:) V2(:)];
         paramhat2=copulafit('Clayton',WW2);
         WWW2=[UUt2(:) VVt2(:)];
         pdf_z_y2=copulapdf('Clayton',WWW2,paramhat2);
         if size(YYY2)==1
            continue
         else
            pdf_diferevalue_val( KVV12)=trapz(YYY2,pdf_z_y2); 
         end
            zzz_va( KVV12)=temp_a1;          
            KVV12= KVV12+1;          
      end
      end
 
 [indexcal1,minv1]=min(abs(difereval-zzz_va));
 [indexcal11,minv11]=min(abs(-difereval-zzz_va));
 for i=2:(KVV12-1)
   cdf_diferevalue_val(i)=trapz(zzz_va(1:i), pdf_diferevalue_val(1:i));
   if cdf_diferevalue_val(i)>1
       cdf_diferevalue_val(i)=1;
   end
 end
 cdf_difereva_va=cdf_diferevalue_val(minv1)-cdf_diferevalue_val(minv11);   
  
 if difereval>0     
     if cdf_difereva_va<0.95
        difference2=0;   %there is no significant different between two models in validation periods             
     else
        difference2=1;   % NSE_E_val1 >NSE_E_val2
     end
  else if difereval==0
          difference2=0;   %there is no significant difference between two models          
      else          
          if cdf_difereva_va<0.95
            difference2=0;   %there is no significant difference between NSE_E_val1 and NSE_E_val1 
          else
            difference2=2;   % NSE_E_val2 <NSE_E_val2 
          end  
       end
  end
  if difference2==0
     str_dif2='There is no significant difference between two models in validation period!';
  else if difference2==1
        str_dif2='The first model performances is significant better than the second one in validaiton period!';
      else
        str_dif2='The second model performances is significant better than the first one in validation period!';
      end
  end
      str_QQ2=['difereval=' num2str(difereval)];
      str_prob_QQ2=['prob_difereval=' num2str(cdf_difereva_va)];
      disp(str_QQ2);
      disp(str_prob_QQ2);
      disp(str_dif2);    
    end
end
   save('prob_difereNSE_val.mat','zzz_va','pdf_diferevalue_val','cdf_diferevalue_val'); 
