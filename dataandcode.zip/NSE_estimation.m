function [A,B,C,DEL,NSE_E] = NSE(obser,simu)
%determine the parameters A,B,C,delta in Eq.(5)
% 
num=size(obser);
rr=corrcoef(obser,simu);
sy=std(simu);
sx=std(obser);

ave_x=mean(obser);
ave_y=mean(simu);
kk1=rr(1,2)*sy/sx;
kk0=ave_y-kk1*ave_x;
ee=(simu-kk0-kk1*obser).^2;

esigma_2=sum(ee)/(num(1,1)-2);
v_2=sum((obser-ave_x).^2);
vo_2=sum(obser.^2);

A=esigma_2*(1+vo_2/(v_2*num(1,1)));
B=esigma_2*1/v_2;
C=-1/v_2;
DEL=A+B*obser.^2;
NSE_E=1-sum((simu-obser).^2)/v_2;
end

