% this progame is for the hypothesis test for NSE between two periods.
% the PDF of NSE in calibration and validation periods are independent.
% this program is draft that should be optimized for improving the
% computing efficiency. if you have any questions, please contace me
% dediliu@whu.edu.cn

clear;
inputdata=xlsread('result_2periods.xlsx');
NO_obs= round(inputdata(1,1));
NO_cal=round(inputdata(1,2));
NO_val=round(inputdata(1,3));

Q_obs=inputdata(2:end,1);
Q_cal=inputdata(2:NO_cal+1,2);
Q_val=inputdata(2:NO_val+1,3);
Q_obsforcal=inputdata(2:NO_cal+1,1); %the observed data should match the calibration
Q_obsforval=inputdata(NO_cal+2:end,1);%the observed data should match the validation
Q_simu=[Q_cal;Q_val];

% linear regression model between observation and simulation
scatter(Q_obs,Q_simu,20,'k');
%for calibration period
[A_cal,B_cal,C_cal,DEL_cal,NSE_E_cal] = NSE_estimation(Q_obsforcal,Q_cal);
[A_val,B_val,C_val,DEL_val,NSE_E_val] = NSE_estimation(Q_obsforval,Q_val);
m_cal=ones(1,NO_cal);
delta_cal=zeros(1,NO_cal);
sigma_cal=0;
const_cal=1;
lambda_cal=C_cal*DEL_cal;
p_cal=1-gx2cdf_davies(NSE_E_cal,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal);

m_val=ones(1,NO_val);
delta_val=zeros(1,NO_val);
sigma_val=0;
const_val=1;
lambda_val=C_val*DEL_val;
p_val=1-gx2cdf_davies(NSE_E_val,lambda_val',m_val,delta_val,sigma_val,const_val);

str_p_cal0=['NSE_E_cal=' num2str(NSE_E_cal)];
str_p_cal=[str_p_cal0 ' and its probability is ' num2str(p_cal*100) '%'];
disp(str_p_cal);
str_p_val0=['NSE_E_val=' num2str(NSE_E_val)];
str_p_val=[str_p_val0 ' and its probability is ' num2str(p_val*100) '%'];
disp(str_p_val);

%to obtain the PDF and CDF of NSE_E_cal
   for i=1:100
        Xvalue(i)=0+(i)/100;   %it depends on the NSE_E_cal and NSE_E_val value ;
        temp_X=Xvalue(i);
        pdf_NSE_cal(i)=gx2pdf_davies(temp_X,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal);
        cdf_NSE_cal(i)=gx2cdf_davies(temp_X,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal) ;

        pdf_NSE_val(i)=gx2pdf_davies(temp_X,lambda_val',m_val,delta_val,sigma_val,const_val);
        cdf_NSE_val(i)=gx2cdf_davies(temp_X,lambda_val',m_val,delta_val,sigma_val,const_val) ;
      end
   save('prob_NSE_cal.mat','Xvalue','pdf_NSE_cal','cdf_NSE_cal'); 
   save('prob_NSE_val.mat','Xvalue','pdf_NSE_val','cdf_NSE_val'); 
% for the differences
if (NSE_E_cal>NSE_E_val) && (p_cal>p_val)
    difference=1;
    disp('The performance of the hydrologic model in calbration period is better than that in validation period!');
    cdf_difereca_va=10;% represnet the (NSE_E_cal>NSE_E_val) && (p_cal>p_val)
else if  (NSE_E_cal<NSE_E_val) && (p_cal<p_val)
        difference=2;
        disp('The performance of the hydrologic model in validation period is better than that in calbration period!');
        cdf_difereca_va=5;% represnet the (NSE_E_cal<NSE_E_val) && (p_cal<p_val)
    else
      disp('Hypothesis tesing should be done!');  
      QQ=NSE_E_cal-NSE_E_val;
      %to obtain the PDF and CDF of QQ
      for i=1:100
        diferevalue(i)=-1+(i)/50;   %it depends on the QQ value;
        temp_a=diferevalue(i);
        if temp_a>=0
           atemp=integral(@(y)gx2pdf_davies(y+temp_a,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),0,1-temp_a);
           cdf_atemp=1-quad2d(@(z,y)gx2pdf_davies(z+y,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),temp_a,1,0,@(z)1-z);
        else
           atemp=integral(@(y)gx2pdf_davies(y+temp_a,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),0,1);
           cdf_atemp=1-quad2d(@(z,y)gx2pdf_davies(z+y,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),temp_a,1,0,1);
        end
        pdf_QQ(i)=atemp;
        cdf_QQ(i)=cdf_atemp;
        XX_QQ(i)=temp_a;
        if (cdf_QQ(i)>0.99999) && (pdf_QQ(i)<0.0000001)
            cdf_QQ(i)=1.0;
            pdf_QQ(i)=0;
            break;
        end
      end
      if QQ>0
         cdf_difereca_va=quad2d(@(z,y)gx2pdf_davies(z+y,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),-QQ,QQ,0,@(z)1-z);
         if cdf_difereca_va<=0.95
             difference=0;   %there is no significant difference between NSE_E_cal and NSE_E_val or qq=0             
         else
             difference=1;   % NSE_E_cal >NSE_E_val or qq>0
         end
      else if QQ==0
             difference=0;   %there is no significant difference between NSE_E_cal and NSE_E_val or qq=0
             cdf_difereca_va=2;%% represnet the NSE_E_cal = NSE_E_val
       else
            cdf_difereca_va=quad2d(@(z,y)gx2pdf_davies(z+y,lambda_cal',m_cal,delta_cal,sigma_cal,const_cal).*gx2pdf_davies(y,lambda_val',m_val,delta_val,sigma_val,const_val),QQ,-QQ,0,@(z)1-z);
          if cdf_difereca_va<=0.95
            difference=0;   %there is no significant difference between NSE_E_cal and NSE_E_val or qq=0
          else
            difference=2;   % NSE_E_cal <NSE_E_val or qq<0
          end  
         end
      end
      if difference==0
          str_dif='There is no significant difference of model performances between two periods!';
      else if difference==1
          str_dif='The model performances in calbration period is better than that in validation period!';
          else
           str_dif='The model performances in validation period is better than that in calbration  period!';
          end
      end
      str_QQ=['QQ=' num2str(QQ)];
      str_prob_QQ=['prob_QQ=' num2str(cdf_difereca_va)];
      disp(str_QQ);
      disp(str_prob_QQ);
      disp(str_dif);
      save('prob_QQ.mat','XX_QQ','pdf_QQ','cdf_QQ'); 
    end
end
